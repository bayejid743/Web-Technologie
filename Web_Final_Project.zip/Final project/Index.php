<?php
    header('location: views/home.html');
?>